import tkinter as tk
from tkinter import ttk, messagebox

# Diccionario de jerarquía del Truco
JERARQUIA_TRUCO = {
    (1, 'espadas'): 14, (1, 'bastos'): 13, (7, 'espadas'): 12, (7, 'oros'): 11,
    (3, 'espadas'): 10, (3, 'bastos'): 10, (3, 'oros'): 10, (3, 'copas'): 10,
    (2, 'espadas'): 9,  (2, 'bastos'): 9,  (2, 'oros'): 9,  (2, 'copas'): 9,
    (1, 'oros'): 8,     (1, 'copas'): 8,
    (12, 'espadas'): 7, (12, 'bastos'): 7, (12, 'oros'): 7, (12, 'copas'): 7,
    (11, 'espadas'): 6, (11, 'bastos'): 6, (11, 'oros'): 6, (11, 'copas'): 6,
    (10, 'espadas'): 5, (10, 'bastos'): 5, (10, 'oros'): 5, (10, 'copas'): 5,
    (7, 'bastos'): 4,   (7, 'copas'): 4,
    (6, 'espadas'): 3,  (6, 'bastos'): 3,  (6, 'oros'): 3,  (6, 'copas'): 3,
    (5, 'espadas'): 2,  (5, 'bastos'): 2,  (5, 'oros'): 2,  (5, 'copas'): 2,
    (4, 'espadas'): 1,  (4, 'bastos'): 1,  (4, 'oros'): 1,  (4, 'copas'): 1,
}

PALOS_VALIDOS = ["espadas", "bastos", "oros", "copas"]
NUMEROS_VALIDOS = [1, 2, 3, 4, 5, 6, 7, 10, 11, 12]

class Carta:
    def __init__(self, numero, palo):
        self.numero = int(numero)
        self.palo = palo.lower()
        self.poder_truco = JERARQUIA_TRUCO.get((self.numero, self.palo), 0)
        self.valor_envido = self.numero if self.numero < 10 else 0

    def __str__(self):
        return f"{self.numero} de {self.palo.capitalize()}"

class AsistenteBot:
    def __init__(self):
        self.mano = []

    def set_mano(self, cartas):
        self.mano = cartas

    def calcular_envido(self):
        if not self.mano: return 0
        palos = {}
        for carta in self.mano:
            if carta.palo not in palos: palos[carta.palo] = []
            palos[carta.palo].append(carta.valor_envido)
        
        max_envido = 0
        for palo, valores in palos.items():
            if len(valores) >= 2:
                valores.sort(reverse=True)
                envido = 20 + valores[0] + valores[1]
            else:
                envido = valores[0]
            if envido > max_envido: max_envido = envido
        return max_envido

    def remover_carta(self, carta):
        for c in self.mano:
            if c.numero == carta.numero and c.palo == carta.palo:
                self.mano.remove(c)
                break

class TrucoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Asistente de Truco - Bot Nivel 1")
        self.bot = AsistenteBot()
        self.crear_interfaz()

    def log(self, mensaje):
        self.consola.config(state='normal')
        self.consola.insert(tk.END, mensaje + "\n")
        self.consola.see(tk.END)
        self.consola.config(state='disabled')

    def validar_carta(self, num_str, palo):
        try:
            num = int(num_str)
            if num not in NUMEROS_VALIDOS:
                raise ValueError
            return Carta(num, palo)
        except ValueError:
            return None

    def cargar_mano(self):
        c1 = self.validar_carta(self.num1.get(), self.palo1.get())
        c2 = self.validar_carta(self.num2.get(), self.palo2.get())
        c3 = self.validar_carta(self.num3.get(), self.palo3.get())

        if not (c1 and c2 and c3):
            messagebox.showerror("Error", "Asegúrate de ingresar números válidos (1-7, 10-12).")
            return

        self.bot.set_mano([c1, c2, c3])
        self.actualizar_vista_mano()
        self.log(f"--- NUEVA MANO CARGADA ---")
        self.log(f"Cartas: {c1}, {c2}, {c3}")
        self.log(f"Puntos de Envido automáticos: {self.bot.calcular_envido()}")

    def actualizar_vista_mano(self):
        if not self.bot.mano:
            self.lbl_mano_actual.config(text="Mano actual: (Vacía)")
        else:
            txt = " | ".join(str(c) for c in self.bot.mano)
            self.lbl_mano_actual.config(text=f"Mano actual: {txt}")

    def consejo_envido(self):
        pts = self.bot.calcular_envido()
        if pts >= 26:
            self.log(f"ENVIDO: Tienes {pts} puntos. ¡ACEPTAR / CANTAR!")
        else:
            self.log(f"ENVIDO: Tienes {pts} puntos. RECHAZAR / IR AL MAZO.")

    def consejo_truco(self):
        if not self.bot.mano:
            self.log("TRUCO: No tienes cartas.")
            return
        
        acepta = any(c.poder_truco >= 9 for c in self.bot.mano)
        if acepta:
            self.log("TRUCO: Tienes cartas fuertes. ¡ACEPTAR / CANTAR!")
        else:
            self.log("TRUCO: Cartas débiles. RECHAZAR.")

    def jugar_carta(self, carta_rival=None):
        if not self.bot.mano:
            self.log("JUGAR: No te quedan cartas.")
            return

        self.bot.mano.sort(key=lambda c: c.poder_truco)
        carta_elegida = None
        motivo = ""

        if carta_rival is None:
            carta_elegida = self.bot.mano[-1]
            motivo = "Abre con tu carta más alta."
        else:
            for carta in self.bot.mano:
                if carta.poder_truco > carta_rival.poder_truco:
                    carta_elegida = carta
                    motivo = "Mata su carta con esta."
                    break
            if not carta_elegida:
                carta_elegida = self.bot.mano[0]
                motivo = "No puedes matarla. Tira tu carta más baja."

        self.log(f"JUGAR: {motivo} -> {carta_elegida}")
        
        # Ventana de confirmación
        if messagebox.askyesno("Confirmación", f"¿Tiraste el {carta_elegida} a la mesa?"):
            self.bot.remover_carta(carta_elegida)
            self.actualizar_vista_mano()
            self.log(f"({carta_elegida} eliminada de la mano)")

    def abrir_mano(self):
        self.jugar_carta()

    def responder_mano(self):
        c_rival = self.validar_carta(self.num_rival.get(), self.palo_rival.get())
        if not c_rival:
            messagebox.showerror("Error", "Ingresa una carta rival válida.")
            return
        self.log(f"Rival tiró: {c_rival}")
        self.jugar_carta(c_rival)

    def crear_interfaz(self):
        frame_top = tk.Frame(self.root, padx=10, pady=10)
        frame_top.pack(fill="x")

        tk.Label(frame_top, text="INGRESO DE CARTAS", font=("Arial", 10, "bold")).grid(row=0, column=0, columnspan=3, pady=5)
        
        # Variables y campos para las 3 cartas
        self.num1 = tk.StringVar()
        self.palo1 = tk.StringVar(value=PALOS_VALIDOS[0])
        tk.Label(frame_top, text="Carta 1:").grid(row=1, column=0)
        tk.Entry(frame_top, textvariable=self.num1, width=5).grid(row=1, column=1, padx=5)
        ttk.Combobox(frame_top, textvariable=self.palo1, values=PALOS_VALIDOS, state="readonly", width=10).grid(row=1, column=2)

        self.num2 = tk.StringVar()
        self.palo2 = tk.StringVar(value=PALOS_VALIDOS[0])
        tk.Label(frame_top, text="Carta 2:").grid(row=2, column=0)
        tk.Entry(frame_top, textvariable=self.num2, width=5).grid(row=2, column=1, padx=5)
        ttk.Combobox(frame_top, textvariable=self.palo2, values=PALOS_VALIDOS, state="readonly", width=10).grid(row=2, column=2)

        self.num3 = tk.StringVar()
        self.palo3 = tk.StringVar(value=PALOS_VALIDOS[0])
        tk.Label(frame_top, text="Carta 3:").grid(row=3, column=0)
        tk.Entry(frame_top, textvariable=self.num3, width=5).grid(row=3, column=1, padx=5)
        ttk.Combobox(frame_top, textvariable=self.palo3, values=PALOS_VALIDOS, state="readonly", width=10).grid(row=3, column=2)

        tk.Button(frame_top, text="Cargar Mano Inicial", command=self.cargar_mano, bg="#4CAF50", fg="white").grid(row=4, column=0, columnspan=3, pady=10)

        # Separador
        ttk.Separator(self.root, orient='horizontal').pack(fill='x', padx=10)

        # Estado Actual
        frame_mid = tk.Frame(self.root, padx=10, pady=5)
        frame_mid.pack(fill="x")
        self.lbl_mano_actual = tk.Label(frame_mid, text="Mano actual: (Vacía)", font=("Arial", 10, "bold"), fg="#333333")
        self.lbl_mano_actual.pack()

        ttk.Separator(self.root, orient='horizontal').pack(fill='x', padx=10)

        # Acciones
        frame_acciones = tk.Frame(self.root, padx=10, pady=10)
        frame_acciones.pack(fill="x")

        tk.Button(frame_acciones, text="¿Qué hago con el Envido?", command=self.consejo_envido).grid(row=0, column=0, padx=5, pady=5)
        tk.Button(frame_acciones, text="¿Qué hago con el Truco?", command=self.consejo_truco).grid(row=0, column=1, padx=5, pady=5)
        tk.Button(frame_acciones, text="Tirar Carta (Abro yo)", command=self.abrir_mano).grid(row=1, column=0, columnspan=2, pady=10, sticky="we", padx=5)

        # Acciones - Responder a rival
        tk.Label(frame_acciones, text="Rival tiró:").grid(row=2, column=0, sticky="e")
        
        frame_rival = tk.Frame(frame_acciones)
        frame_rival.grid(row=2, column=1, sticky="w")
        
        self.num_rival = tk.StringVar()
        self.palo_rival = tk.StringVar(value=PALOS_VALIDOS[0])
        tk.Entry(frame_rival, textvariable=self.num_rival, width=5).pack(side=tk.LEFT, padx=2)
        ttk.Combobox(frame_rival, textvariable=self.palo_rival, values=PALOS_VALIDOS, state="readonly", width=10).pack(side=tk.LEFT)
        
        tk.Button(frame_acciones, text="Responder a Rival", command=self.responder_mano, bg="#2196F3", fg="white").grid(row=3, column=0, columnspan=2, pady=5, sticky="we", padx=5)

        # Consola de salida
        frame_bottom = tk.Frame(self.root, padx=10, pady=10)
        frame_bottom.pack(fill="both", expand=True)
        tk.Label(frame_bottom, text="Consejos del Bot:").pack(anchor="w")
        self.consola = tk.Text(frame_bottom, height=8, width=50, state='disabled', bg="#f4f4f4")
        self.consola.pack(fill="both", expand=True)

if __name__ == "__main__":
    root = tk.Tk()
    app = TrucoApp(root)
    root.mainloop()